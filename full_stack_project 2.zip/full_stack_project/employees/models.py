from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator, MaxLengthValidator, MinLengthValidator


class Employee_ID(models.Model):
    employee_id = models.IntegerField(null=True, validators=[MinValueValidator(1000), MaxValueValidator(9999)])

    def __str__(self):
        return f"{self.employee_id}"


class Specialist(models.Model):
    specialist = models.CharField(max_length=50)

    def __str__(self):
        return self.specialist


class Title(models.Model):
    title = models.CharField(max_length=50)
    specialist = models.ManyToManyField(Specialist)

    def __str__(self):
        return self.title



class Employee(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50, null=True)
    employee_id = models.ForeignKey(Employee_ID, on_delete=models.CASCADE, null=True)
    email_address = models.EmailField(max_length=200, null=True)
    phone_number = models.IntegerField(null=True)
    hire_date = models.DateField(null=True)
    salary = models.IntegerField(null=True, validators=[MinValueValidator(1000), MaxValueValidator(1000000)])
    title = models.ForeignKey(Title, on_delete=models.CASCADE, null=True)
    slug = models.SlugField(null=True)
    photo = models.ImageField(default='default.png', blank=False)


    def __str__(self):
        return f"{self.first_name} {self.last_name} | {self.title} | Employee ID: {self.employee_id}"


class Manager(models.Model):
    manager_details = models.ForeignKey(Employee, on_delete=models.CASCADE, null=True)
    direct_reporter_id = models.ManyToManyField(Employee_ID)

    def __str__(self):
        return f"{self.manager_details}"
