from django.contrib import admin
from .models import Employee, Employee_ID, Specialist, Title, Manager

admin.site.register(Employee)
admin.site.register(Employee_ID)
admin.site.register(Specialist)
admin.site.register(Title)
admin.site.register(Manager)



