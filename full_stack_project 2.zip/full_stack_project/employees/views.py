from django.shortcuts import render
from rest_framework import viewsets
from .models import Employee, Title, Specialist, Manager, Employee_ID
from .serializers import EmployeeSerializer, TitleSerializer, SpecialistSerializer, ManagerSerializer, Employee_IDSerializer

class EmployeeView(viewsets.ModelViewSet):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer

class TitleView(viewsets.ModelViewSet):
    queryset = Title.objects.all()
    serializer_class = TitleSerializer

class SpecialistView(viewsets.ModelViewSet):
    queryset = Specialist.objects.all()
    serializer_class = SpecialistSerializer

class ManagerView(viewsets.ModelViewSet):
    queryset = Manager.objects.all()
    serializer_class = ManagerSerializer

class Employee_IDView(viewsets.ModelViewSet):
    queryset = Employee_ID.objects.all()
    serializer_class = Employee_IDSerializer

def homepage(request):
    employees = Employee.objects.all()
    return render(request, 'homepage.html', {'employees':employees})

def details(request, slug):
    employee = Employee.objects.get(slug=slug)
    return render(request, 'details.html', {'employee':employee})


